create_clock -name CLK_2_5M -period 400.000 [get_ports {SPI_SDIO SPI_CS SPI_SCLK}]
create_clock -name CLK_50M -period 20.000 [get_ports {SYS_CLK}]

derive_pll_clocks
derive_clock_uncertainty
