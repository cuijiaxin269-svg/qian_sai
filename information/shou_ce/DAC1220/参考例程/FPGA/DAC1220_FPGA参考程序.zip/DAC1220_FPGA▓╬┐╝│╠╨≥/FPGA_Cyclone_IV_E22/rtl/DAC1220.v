module DAC1220(
	input		wire	        SYS_CLK	,
	input		wire	        SYS_RST	,
	input   wire  [19:0]  DC_DATA , // 输出电压计算公式： (FREQ_DATA - 2^19) * (20 / 2^20) V;
	output	wire	        SPI_CS	,
	output	wire	        SPI_SCLK,
	output	wire	        SPI_SDIO
);

// 输出电压配置是二进制的形式，看数据手册的第14页
localparam	delay_500ms  = (200_000 / 2   ) - 1;
localparam	delay_50ms   = (200_000 / 20  ) - 1;

localparam	cycle_counter_8  = (8  * 2) - 1;
localparam	cycle_counter_16 = (16 * 2) - 1;
localparam	cycle_counter_24 = (24 * 2) - 1;


// 写地址参考数据手册第12页
localparam	WRITE = 1'b0;
localparam	READ  = 1'b1;
localparam	MB_0 = 3'b000; // 写入一个字节
localparam	MB_1 = 3'b010; // 写入二个字节
localparam	MB_2 = 3'b100; // 写入三个字节

// 寄存器命令参考数据手册第15页
localparam	DIR_byte2 = 4'b0000;	// 数据寄存器高8位
localparam	DIR_byte1 = 4'b0001;  // 数据寄存器中间8位
localparam	DIR_byte0 = 4'b0010;  // 数据寄存器低8位

localparam	CMR_byte1 = 4'b0100;  // 命令寄存器高8位
localparam	CMR_byte0 = 4'b0101;  // 命令寄存器低8位

localparam	OCR_byte2 = 4'b1000;  // 偏移量校准寄存器高8位
localparam	OCR_byte1 = 4'b1001;  // 偏移量校准寄存器中间8位
localparam	OCR_byte0 = 4'b1010;  // 偏移量校准寄存器低8位

localparam	FCR_byte2 = 4'b1100;  // 全局校准寄存器高8位
localparam	FCR_byte1 = 4'b1101;  // 全局校准寄存器中间8位 
localparam	FCR_byte0 = 4'b1110;  // 全局校准寄存器低8位

wire	CLK_200Khz; // 0.000005
reg		CS			;
reg		SCLK		;
reg		MOSI		;

reg	 [31:0]	SEND_DATA	;
reg	 [31:0]	SPI_DATA	;
reg	 [31:0]	DAC_DATA	;
reg	     		DATA_STATE;
 
reg	 [5:0]		cycle_cnt	;
reg	 [4:0]		SYS_STATE	;

reg	 [31:0] 	delay_cnt ;

wire [19:0]   DAC_Volt;

reg		cs_first	;
wire	cs_nege  	;

// 锁相环模块
PLL_CLK u_PLL_CLK(
	.areset	(~SYS_RST		),
	.inclk0	(SYS_CLK		),
	.c0			(CLK_200Khz	)
);

assign DAC_Volt = DC_DATA;  

//主控制器模块
always@(posedge CLK_200Khz or negedge SYS_RST)
begin
	if(!SYS_RST)begin
		CS		<= 1'b1;
		SCLK  <= 1'b0;
		cycle_cnt	 <= 6'd0;
		SEND_DATA	 <= 32'd0;	
		delay_cnt  <= 32'd0;
		SYS_STATE	 <= 5'd0;	
	end
	else begin
		case(SYS_STATE)
			5'd0:	begin	// IO口,参数初始化
							CS		<= 1'b1;
							SCLK  <= 1'b0;
							cycle_cnt	 <= 6'd0;
							SEND_DATA	 <= 32'd0;	
							if(delay_cnt >= delay_500ms)begin
								delay_cnt <= 32'd0;
								SYS_STATE	<= 5'd1;	
							end
							else begin
								delay_cnt <= delay_cnt + 1'b1;
								SYS_STATE	<= 5'd0;	
							end
						end
			5'd1: begin // 芯片复位
							CS		<= 1'b0;
							SCLK  <= 1'b0;	
							if(delay_cnt >= 32'd100)begin // 81.92
								delay_cnt <= 32'd0;
								SYS_STATE	<= 5'd2;	
							end
							else begin
								delay_cnt <= delay_cnt + 1'b1;
								SYS_STATE	<= 5'd1;	
							end
						end
			5'd2:	begin
							SCLK  <= 1'b1;	
							if(delay_cnt >= 32'd45)begin // 512*0.0000004  / 0.000005  
								delay_cnt <= 32'd0;
								SYS_STATE	<= 5'd3;	
							end
							else begin
								delay_cnt <= delay_cnt + 1'b1;
								SYS_STATE	<= 5'd2;					
							end
						end
			5'd3: begin
							SCLK  <= 1'b0;	
							if(delay_cnt >= 32'd10)begin
								delay_cnt <= 32'd0;
								SYS_STATE	<= 5'd4;	
							end
							else begin
								delay_cnt <= delay_cnt + 1'b1;
								SYS_STATE	<= 5'd3;					
							end	
						end
			5'd4: begin
							SCLK  <= 1'b1;	
							if(delay_cnt >= 32'd85)begin // 
								delay_cnt <= 32'd0;
								SYS_STATE	<= 5'd5;	
							end
							else begin
								delay_cnt <= delay_cnt + 1'b1;
								SYS_STATE	<= 5'd4;					
							end	
						end
			5'd5: begin
							SCLK  <= 1'b0;	
							if(delay_cnt >= 32'd10)begin
								delay_cnt <= 32'd0;
								SYS_STATE	<= 5'd6;	
							end
							else begin
								delay_cnt <= delay_cnt + 1'b1;
								SYS_STATE	<= 5'd5;					
							end	
						end
			5'd6: begin
							SCLK  <= 1'b1;	
							if(delay_cnt >= 32'd170)begin // 
								delay_cnt <= 32'd0;
								SYS_STATE	<= 5'd7;	
							end
							else begin
								delay_cnt <= delay_cnt + 1'b1;
								SYS_STATE	<= 5'd6;					
							end	
						end
			5'd7: begin //复位完成延时拉高CS
							SCLK  <= 1'b0;	
							if(delay_cnt >= delay_50ms)begin
								delay_cnt <= 32'd0;
								SYS_STATE	<= 5'd8;	
							end
							else begin
								delay_cnt <= delay_cnt + 1'b1;
								SYS_STATE	<= 5'd7;					
							end
						end
			5'd8: begin
							CS		<= 1'b1;
							SCLK  <= 1'b0;
							SEND_DATA <= {WRITE,MB_1,CMR_byte1,8'h00,4'b1010,4'b0001,8'd0};
							if(delay_cnt >= 32'd2)begin
								delay_cnt <= 32'd0;
								SYS_STATE	<= 5'd9;	
							end
							else begin
								delay_cnt <= delay_cnt + 1'b1;
								SYS_STATE	<= 5'd8;					
							end
						end
			5'd9: begin // CS拉低后延时400ns * 11
							CS		<= 1'b0;
							SCLK  <= 1'b0;
							if(delay_cnt >= 32'd5)begin
								delay_cnt <= 32'd0;
								SYS_STATE	<= 5'd10;	
							end
							else begin
								delay_cnt <= delay_cnt + 1'b1;
								SYS_STATE	<= 5'd9;					
							end
						end
			5'd10:begin
							if(cycle_cnt >= cycle_counter_8)begin
								SCLK <= ~SCLK;
								cycle_cnt <= 6'd0;
								SYS_STATE	<= 5'd11;
							end
							else begin
								SCLK <= ~SCLK;
								cycle_cnt <= cycle_cnt + 1'b1;
								SYS_STATE	<= 5'd10;
							end
						end
			5'd11:begin // 一次字节写入延时400ns * 13
							CS		<= 1'b0;
							SCLK  <= 1'b0;
							if(delay_cnt >= 32'd8)begin
								delay_cnt <= 32'd0;
								SYS_STATE	<= 5'd12;	
							end
							else begin
								delay_cnt <= delay_cnt + 1'b1;
								SYS_STATE	<= 5'd11;					
							end
						end
			5'd12:begin
							if(cycle_cnt >= cycle_counter_16)begin
								SCLK <= ~SCLK;
								cycle_cnt <= 6'd0;
								SYS_STATE	<= 5'd13;
							end
							else begin
								SCLK <= ~SCLK;
								cycle_cnt <= cycle_cnt + 1'b1;
								SYS_STATE	<= 5'd12;
							end
						end
			5'd13:begin // 延时400ns * 11 拉高cs
							CS		<= 1'b0;
							SCLK  <= 1'b0;
							if(delay_cnt >= 32'd5)begin
								delay_cnt <= 32'd0;
								SYS_STATE	<= 5'd14;	
							end
							else begin
								delay_cnt <= delay_cnt + 1'b1;
								SYS_STATE	<= 5'd13;					
							end
						end
			5'd14:begin // 一轮配置结束CS 拉高至少 400ns * 22
							CS		<= 1'b1;
							SCLK  <= 1'b0;
							if(delay_cnt >= 32'd12)begin
								delay_cnt <= 32'd0;
								SYS_STATE	<= 5'd15;	
							end
							else begin
								delay_cnt <= delay_cnt + 1'b1;
								SYS_STATE	<= 5'd14;					
							end
						end
			5'd15:begin
							CS		<= 1'b1;
							SCLK  <= 1'b0;
							SYS_STATE	 <= 5'd16;		
						end
			5'd16:begin
							CS		<= 1'b1;
							SCLK  <= 1'b0;
							if(delay_cnt >= delay_500ms)begin // 配置完成延时500MS
								delay_cnt <= 32'd0;
								SYS_STATE	<= 5'd17;	
							end
							else begin
								delay_cnt <= delay_cnt + 1'b1;
								SYS_STATE	<= 5'd16;					
							end
						end
			5'd17:begin
							CS		<= 1'b1;
							SCLK  <= 1'b0;
							SEND_DATA <= {WRITE,MB_2,DIR_byte2,DAC_Volt,4'b0000};
							if(delay_cnt >= 32'd10)begin
								delay_cnt <= 32'd0;
								SYS_STATE	<= 5'd18;	
							end
							else begin
								delay_cnt <= delay_cnt + 1'b1;
								SYS_STATE	<= 5'd17;					
							end
						end
			5'd18:begin // CS拉低后延时400ns * 11
							CS		<= 1'b0;
							SCLK  <= 1'b0;
							if(delay_cnt >= 32'd2)begin
								delay_cnt <= 32'd0;
								SYS_STATE	<= 5'd19;	
							end
							else begin
								delay_cnt <= delay_cnt + 1'b1;
								SYS_STATE	<= 5'd18;					
							end
						end
			5'd19:begin
							if(cycle_cnt >= cycle_counter_8)begin
								SCLK <= ~SCLK;
								cycle_cnt <= 6'd0;
								SYS_STATE	<= 5'd20;
							end
							else begin
								SCLK <= ~SCLK;
								cycle_cnt <= cycle_cnt + 1'b1;
								SYS_STATE	<= 5'd19;
							end
						end
			5'd20:begin
							CS		<= 1'b0;
							SCLK  <= 1'b0;
							if(delay_cnt >= 32'd5)begin
								delay_cnt <= 32'd0;
								SYS_STATE	<= 5'd21;	
							end
							else begin
								delay_cnt <= delay_cnt + 1'b1;
								SYS_STATE	<= 5'd20;					
							end
						end
			5'd21:begin
							if(cycle_cnt >= cycle_counter_24)begin
								SCLK <= ~SCLK;
								cycle_cnt <= 6'd0;
								SYS_STATE	<= 5'd22;
							end
							else begin
								SCLK <= ~SCLK;
								cycle_cnt <= cycle_cnt + 1'b1;
								SYS_STATE	<= 5'd21;
							end
						end
			5'd22:begin
							CS		<= 1'b0;
							SCLK  <= 1'b0;
							if(delay_cnt >= 32'd2)begin
								delay_cnt <= 32'd0;
								SYS_STATE	<= 5'd23;	
							end
							else begin
								delay_cnt <= delay_cnt + 1'b1;
								SYS_STATE	<= 5'd22;					
							end
						end
			5'd23:begin
							CS		<= 1'b1;
							SCLK  <= 1'b0;
							if(delay_cnt >= delay_50ms)begin
								delay_cnt <= 32'd0;
								SYS_STATE	<= 5'd17;	
							end
							else begin
								delay_cnt <= delay_cnt + 1'b1;
								SYS_STATE	<= 5'd23;					
							end
						end
			default:SYS_STATE	<= 5'd0;
		endcase
	end
end

// 对CS进行打拍处理
always@(posedge CLK_200Khz or negedge SYS_RST)
begin
	if(!SYS_RST)begin
		cs_first <= 1'b0;
	end
	else begin
		cs_first <= SPI_CS;	
	end
end

assign cs_nege = (!SPI_CS) & cs_first ;


// 芯片是在SLCK的下降沿进行数据的处理，所以在上升沿要对数据进行移位处理
always@(posedge SPI_SCLK or negedge SYS_RST	or posedge cs_nege)
begin
	if(!SYS_RST)begin
		SPI_DATA <= 32'd0;
		MOSI <= 1'b0;
	end
	else if(cs_nege)begin
		MOSI <= 1'b0;
		SPI_DATA <= SEND_DATA;
	end
	else begin
		MOSI <= SPI_DATA[31];
		SPI_DATA <= {SPI_DATA[30:0],1'b0};
	end
end

assign SPI_CS		=  CS		;
assign SPI_SCLK	=  SCLK ;
assign SPI_SDIO	=  (!SPI_CS) ? MOSI : 1'b0 ;

endmodule

