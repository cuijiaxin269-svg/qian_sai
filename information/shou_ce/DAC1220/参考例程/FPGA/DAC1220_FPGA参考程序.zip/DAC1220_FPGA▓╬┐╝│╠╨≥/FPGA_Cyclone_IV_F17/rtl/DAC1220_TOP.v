module DAC1220_TOP(
    input   wire  SYS_CLK ,
    input   wire  SYS_RST ,
    output  wire  SPI_CS  ,
    output  wire  SPI_SCLK,
    output  wire  SPI_SDIO
);

DAC1220 u_DAC1220(
    .SYS_CLK  (SYS_CLK    ),
    .SYS_RST  (SYS_RST    ),
    .DC_DATA  (20'd1048575), // 输出电压计算公式： (FREQ_DATA - 2^19)  * (20 / 2^20)V;
    .SPI_CS   (SPI_CS     ),
    .SPI_SCLK (SPI_SCLK   ),
    .SPI_SDIO (SPI_SDIO   )
);

endmodule
